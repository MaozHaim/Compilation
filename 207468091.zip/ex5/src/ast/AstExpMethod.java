package ast;

import ir.Ir;
import ir.IrCommandCallMethod;
import ir.IrCommandLoad;
import ir.IrPatterns;
import symboltable.SymbolTable;
import temp.Temp;
import types.Type;
import types.TypeClass;
import types.TypeFunction;
import utils.Utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class AstExpMethod extends AstExp{
    public AstVar var;
    public String methodName;
    public TypeClass classData;
    public List<AstExp> exps;

    public AstExpMethod(AstVar var, String methodName, int lineNum){
        super("exp -> var DOT ID LPAREN RPAREN", lineNum);
        this.methodName = methodName;
        this.var = var;
        exps = Arrays.asList();
    }

    public AstExpMethod(AstVar var, String methodName, NodeList<AstExp> expStar, int lineNum){
        super("exp -> var DOT ID LPAREN exp* RPAREN", lineNum);
        this.methodName = methodName;
        this.var = var;
        exps = expStar.unroll();
    }

    
    @Override
    protected List<? extends AstNode> GetChildren() {
        List<AstNode> children = new ArrayList<>(exps);
        children.add(0, var);
        return children;
    }

    
    @Override
    protected String GetNodeName() {
        return String.format("VAR.%s(%s)", methodName, exps != null ? "PARAMS" : "");
    }


    private List<Type> expsToList() {
        List<Type> argumentTypes = new ArrayList<>();
        for (AstExp expression : exps) {
            argumentTypes.add(expression.SemantMe());
        }
        return argumentTypes;
    }


    @Override
    public Type SemantMe() {
        SymbolTable table = SymbolTable.getInstance();
        Type data = var.SemantMe();
        if (!(data instanceof TypeClass)) {
            throwException("Attempting to call method on a non-class type.");
        }

        this.classData = (TypeClass) data;

        Type methodType = table.findMemberType(this.classData, methodName);

        if (!(methodType instanceof TypeFunction)) {
            throwException("Attempting to call attribute as a method.");
        }

        TypeFunction functionData = (TypeFunction)methodType;
        Type returnType = functionData.returnType;
        List<Type> argsList = expsToList();

        if (!(Utils.matchTypesArgsParams(argsList, functionData.params))){
            throwException("Bad parameters or arguments.");
        }

        return returnType;
    }


    @Override
    public Temp IRme() {
        Ir ir = Ir.getInstance();

        List<Temp> arguments = new ArrayList<>();
        for (AstExp exp : exps) {
            arguments.add(exp.IRme());
        }

        int methodOffset = classData.getMethodIndex(methodName);

        // var.IRme() returns the address of the storage holding the object
        // pointer; load it to test for nil, then pass the address through to
        // IrCommandCallMethod (which loads it again internally).
        Temp callerAddr = var.IRme();
        Temp callerVal = new Temp();
        ir.AddIrCommand(new IrCommandLoad(callerVal, callerAddr, 0));
        IrPatterns.checkNullRef(callerVal);

        Temp dst = new Temp();
        ir.AddIrCommand(new IrCommandCallMethod(methodName, methodOffset, callerAddr, arguments, dst));

        return dst;
    }
}
